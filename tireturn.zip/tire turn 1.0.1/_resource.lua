resource_manifest_version 'cerulean'

description 'Wheel Position Saved on Exit of Vehicle'
author 'SkyLightFox'
version '1.0.1'
date '05/29/2025'

client_scripts {

  'client.lua',

}