resource_manifest_version 'cerulean'

description 'Wheel Position Saved on Exit of Vehicle'
author 'SkyLightFox'
version '1.0.0'
date '5/19/2025'

version '1.0.0'

client_scripts {

  'client.lua',

}